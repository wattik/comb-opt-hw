from typing import List
from io import TextIOWrapper

IO = TextIOWrapper


class Reader:
    @staticmethod
    def integer_list_line(file: IO) -> List[int]:
        line = file.readline()
        return [int(i) for i in line.split(" ")]


class Writer:
    @staticmethod
    def integer_list_line(file: IO, integers: List[int]) -> None:
        file.write(" ".join(str(int(round(i))) for i in integers) + "\n")

    @staticmethod
    def integer(file: IO, integer: int) -> None:
        file.write(str(int(round(integer))) + "\n")
