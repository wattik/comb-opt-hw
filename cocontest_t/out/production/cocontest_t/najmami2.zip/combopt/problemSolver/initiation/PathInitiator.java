package combopt.problemSolver.initiation;

import combopt.problemSolver.entity.Path;

public interface PathInitiator {
    public Path initiatePath(String origin);
}
