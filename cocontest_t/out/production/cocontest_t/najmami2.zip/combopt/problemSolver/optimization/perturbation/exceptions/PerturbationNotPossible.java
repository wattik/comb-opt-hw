package combopt.problemSolver.optimization.perturbation.exceptions;

public class PerturbationNotPossible extends Exception {
    public PerturbationNotPossible(String s) {
        super(s);
    }
}
