package combopt.problemSolver.optimization.perturbation.exceptions;

public class OptimizerFinished extends PerturbationNotPossible {
    public OptimizerFinished(String s) {
        super(s);
    }
}
