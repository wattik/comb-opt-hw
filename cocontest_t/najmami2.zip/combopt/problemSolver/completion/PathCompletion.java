package combopt.problemSolver.completion;

import combopt.problemSolver.entity.Path;

public interface PathCompletion {

    public Path complete(Path path);
}
