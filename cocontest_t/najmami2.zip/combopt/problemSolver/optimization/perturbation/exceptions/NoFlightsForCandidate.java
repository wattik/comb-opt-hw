package combopt.problemSolver.optimization.perturbation.exceptions;

public class NoFlightsForCandidate extends PerturbationNotPossible{
    public NoFlightsForCandidate(String s) {
        super(s);
    }
}
